INSERT INTO `usersi` (`username`, `password`) VALUES ('A', '111111');
INSERT INTO `usersi` (`username`, `password`) VALUES ('T', '123456');
