INSERT INTO `studenti` (`name`, `number`, `teacher`, `major`, `english`, `math`, `physics`) VALUES ('李华', 20220101, '段', '计算机科学与技术', 87, 98, 89);
INSERT INTO `studenti` (`name`, `number`, `teacher`, `major`, `english`, `math`, `physics`) VALUES ('王五', 20220102, '谭', '电气工程', 92, 96, 87);
